LINK A GITHUB:
https://github.com/FabianTenorioClaros/ansible-proyecto.git

PASOS PARA EJECUTAR EL PROYECTO:
1. ansible-playbook -i hosts.ini playbook.yml
